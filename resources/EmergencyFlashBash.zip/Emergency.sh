#!/sbin/sh

/sbin/mount -a

export DIRECTORY=/sdcard/ROMInstaller
export FILE=$DIRECTORY/preferences.prop

if [ ! -d "$DIRECTORY" ]; then
	mkdir -p /sdcard/ROMInstaller
fi

if [ ! -f $FILE ]; then
	echo "YourPreferenceID=PreferenceValue" >> $FILE
	echo "YourPreferenceID2=PreferenceValue2" >> $FILE
	echo "..."
fi
